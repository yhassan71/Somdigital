import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import AboutUsSection from "@/components/about-us-section";
import InteractiveGISSection from "@/components/interactive-gis-section";
import ServicesSection from "@/components/services-section";
import GISShowcaseSection from "@/components/gis-showcase-section";
import SoftwareSolutionsSection from "@/components/software-solutions-section";
import PortfolioSection from "@/components/portfolio-section";
import AboutSection from "@/components/about-section";
import ContactSection from "@/components/contact-section";
import CTASection from "@/components/cta-section";
import Footer from "@/components/footer";

export default function Home() {
  const scrollToAbout = () => {
    const element = document.getElementById("about");
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  const scrollToServices = () => {
    const element = document.getElementById("services");
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <HeroSection />
      <AboutUsSection />
      <InteractiveGISSection />
      <ServicesSection />
      <GISShowcaseSection />
      <SoftwareSolutionsSection />
      <PortfolioSection />
      <AboutSection />
      <ContactSection />
      <CTASection />
      <Footer />
    </div>
  );
}
