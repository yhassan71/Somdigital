import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { Users, Briefcase, Shield, Monitor, TrendingUp, Award } from "lucide-react";

export default function TeamPage() {
  const teamMembers = [
    {
      name: "Avv Abdullahi Mohodin Hassan (Abdullahi Yabarow)",
      position: "CEO",
      description: "Leading UCSSOM's vision for strengthening governance and regulatory enforcement across Somalia.",
      icon: Award,
    },
    {
      name: "Ali Adan",
      position: "Director of Operations",
      description: "Overseeing daily operations and ensuring efficient service delivery across all compliance sectors.",
      icon: Briefcase,
    },
    {
      name: "Suad Mohamed G",
      position: "HR Manager",
      description: "Managing human resources and fostering a collaborative work environment for our team.",
      icon: Users,
    },
    {
      name: "Avv. Iman Abdikarin",
      position: "Head of Legal Compliance",
      description: "Ensuring all regulatory frameworks and legal compliance standards are maintained.",
      icon: Shield,
    },
    {
      name: "Mike Kivu",
      position: "IT Manager",
      description: "Managing our digital infrastructure and ensuring secure, reliable technology solutions.",
      icon: Monitor,
    },
    {
      name: "Zakaria Hassan Husein",
      position: "Digital Marketing Strategist",
      description: "Expert in digital marketing strategies, SEO optimization, and online brand development for businesses across Somalia.",
      icon: TrendingUp,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-r from-slate-800 to-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Our Leadership Team
            </h1>
            <p className="text-xl text-slate-200 max-w-3xl mx-auto">
              Our experienced leadership team brings together expertise in governance, operations, legal compliance, human resources, and technology to deliver comprehensive solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Team Members Section */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {teamMembers.map((member, index) => {
              const IconComponent = member.icon;
              return (
                <div key={index} className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow duration-300">
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-brand-blue rounded-full flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-slate-800 mb-2">{member.name}</h3>
                    <p className="text-brand-blue font-semibold text-lg">{member.position}</p>
                  </div>
                  <p className="text-slate-600 text-center leading-relaxed">
                    {member.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}