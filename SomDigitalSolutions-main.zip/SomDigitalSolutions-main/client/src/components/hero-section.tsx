import { Button } from "@/components/ui/button";
import somaliaVideoPath from "@assets/Somalia-World-Map-2024-02-28-05-35-33-Utc1_1754157433880.mp4";

export default function HeroSection() {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  const scrollToAbout = () => {
    const element = document.getElementById("about");
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <section id="home" className="pt-20 relative overflow-hidden bg-slate-900 text-white">
      {/* GIS Video Background */}
      <div className="absolute inset-0 w-full h-full overflow-hidden">
        <video
          autoPlay
          muted
          loop
          playsInline
          className="w-full h-full object-cover"
          style={{ filter: 'brightness(0.6) contrast(1.1)' }}
        >
          <source src={somaliaVideoPath} type="video/mp4" />
        </video>
        
        {/* Light overlay for text readability only */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-black/20 to-black/40"></div>
      </div>

      {/* Top contact info bar */}
      <div className="relative z-10 bg-slate-900 bg-opacity-80 border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-2 md:space-y-0 text-sm text-slate-300">
            <div className="flex flex-col md:flex-row md:space-x-8 space-y-1 md:space-y-0">
              <span>📍 KM4 Road, Mogadishu, Somalia</span>
              <span>✉ info@somdigitalsolutions.so</span>
            </div>
            <span>🕐 Office Hours: 8:00 AM – 4:45 PM</span>
          </div>
        </div>
      </div>

      {/* Main hero content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 lg:pr-8">
            <div className="space-y-6">
              <h3 className="text-xl font-medium text-brand-amber uppercase tracking-wide">
                From Complexity to Clarity
              </h3>
              <h1 className="text-4xl lg:text-5xl font-bold leading-tight text-white">
                Empowering Your Growth
              </h1>
              <Button
                onClick={scrollToContact}
                className="bg-brand-blue hover:bg-blue-800 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-200 shadow-lg"
              >
                Get started
              </Button>
            </div>
            
            <div className="space-y-4">
              <h2 className="text-2xl lg:text-3xl font-bold text-white">
                Explore our comprehensive Tech solutions to meet your immediate requirements
              </h2>
              <h3 className="text-xl text-slate-200 font-medium">
                Join us on a journey where every click unlocks new possibilities
              </h3>
              <Button
                onClick={scrollToAbout}
                variant="outline"
                className="border-2 border-white text-white hover:bg-white hover:text-slate-900 px-8 py-3 rounded-lg font-semibold transition-all duration-200 bg-black/30 backdrop-blur-sm"
              >
                About us
              </Button>
            </div>
          </div>

          <div className="lg:text-center">
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1559526324-4b87b5e36e44?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Hand tapping tablet with map - GIS and GPS technology solutions" 
                className="w-full h-auto max-w-lg mx-auto rounded-lg shadow-2xl" 
              />
              {/* Glow effect */}
              <div className="absolute inset-0 rounded-lg bg-gradient-to-tr from-brand-blue/20 to-brand-amber/20 pointer-events-none"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
