import { Globe, Code, TrendingUp, Smartphone, MapPin, Database } from "lucide-react";

export default function ServicesSection() {
  const services = [
    {
      icon: Globe,
      title: "Web Development",
      description: "Modern, responsive websites and web applications built with cutting-edge technologies for optimal performance.",
    },
    {
      icon: Code,
      title: "Software Development", 
      description: "Custom software solutions tailored to your business needs, from desktop applications to enterprise systems.",
    },
    {
      icon: TrendingUp,
      title: "Digital Marketing",
      description: "Comprehensive digital marketing strategies including SEO, social media, and online advertising campaigns.",
    },
    {
      icon: Smartphone,
      title: "Mobile App Development",
      description: "Native and cross-platform mobile applications for iOS and Android with intuitive user experiences.",
    },
    {
      icon: MapPin,
      title: "GIS Mapping",
      description: "Geographic Information Systems and spatial data solutions for mapping, analysis, and visualization needs.",
    },
    {
      icon: Database,
      title: "Data Digitalization",
      description: "Converting physical documents and records to digital formats for improved accessibility and management.",
    },
  ];

  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <section id="services" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-800 mb-4">Our Services</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Comprehensive technology solutions designed to meet your business needs
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div key={index} className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
                <div className="text-brand-blue text-4xl mb-6">
                  <IconComponent className="w-10 h-10" />
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-4">{service.title}</h3>
                <p className="text-slate-600 mb-4">{service.description}</p>
                <button 
                  onClick={scrollToContact}
                  className="text-brand-blue font-semibold hover:text-blue-800 transition-colors duration-200"
                >
                  Learn More →
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
