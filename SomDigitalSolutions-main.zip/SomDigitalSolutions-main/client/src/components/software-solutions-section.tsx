import { Monitor, Building2, FileText, Home, Heart, Hotel, ShoppingCart, Scale, Users } from "lucide-react";

export default function SoftwareSolutionsSection() {
  const softwareSolutions = [
    {
      icon: <Monitor className="w-8 h-8 text-brand-blue" />,
      title: "School Management System",
      description: "Comprehensive educational institution management with student records, attendance tracking, grade management, and administrative tools."
    },
    {
      icon: <FileText className="w-8 h-8 text-brand-blue" />,
      title: "Urban Compliance Standards Somalia (UCSSOM) System",
      description: "Advanced compliance management system for urban development standards and regulatory requirements in Somalia."
    },
    {
      icon: <Building2 className="w-8 h-8 text-brand-blue" />,
      title: "Real Estate Management System",
      description: "Property management platform with listing management, client tracking, transaction processing, and market analytics."
    },
    {
      icon: <Home className="w-8 h-8 text-brand-blue" />,
      title: "SACCO/Microfinance Management System",
      description: "Financial cooperative management with member accounts, loan processing, savings tracking, and financial reporting."
    },
    {
      icon: <Heart className="w-8 h-8 text-brand-blue" />,
      title: "Hospital Management System",
      description: "Healthcare facility management with patient records, appointment scheduling, billing, and medical inventory management."
    },
    {
      icon: <Hotel className="w-8 h-8 text-brand-blue" />,
      title: "Hotel Management System",
      description: "Hospitality management platform with reservation system, guest services, room management, and revenue tracking."
    },
    {
      icon: <ShoppingCart className="w-8 h-8 text-brand-blue" />,
      title: "Point of Sale System",
      description: "Retail management solution with inventory tracking, sales processing, customer management, and business analytics."
    },
    {
      icon: <Scale className="w-8 h-8 text-brand-blue" />,
      title: "Law Firm Management System",
      description: "Comprehensive legal practice management with case tracking, client management, document handling, billing, and court schedule management."
    },
    {
      icon: <Users className="w-8 h-8 text-brand-blue" />,
      title: "HR/Payroll Management System",
      description: "Human resources and payroll management with employee records, attendance tracking, salary processing, benefits administration, and performance management."
    }
  ];

  return (
    <section id="software-solutions" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-800 mb-4">Custom Software Management Systems</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto mb-8">
            Tailored software solutions designed specifically for your industry needs, built with cutting-edge technology and deep understanding of local business requirements.
          </p>
          
          {/* Software Development Image */}
          <div className="max-w-4xl mx-auto mb-12">
            <img 
              src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600"
              alt="Software development process showing coding, testing, and deployment workflows"
              className="w-full h-64 md:h-80 object-cover rounded-xl shadow-lg"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-brand-blue/10 to-transparent rounded-xl"></div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {softwareSolutions.map((solution, index) => (
            <div key={index} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 border border-slate-100">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 bg-blue-50 p-3 rounded-lg">
                  {solution.icon}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-slate-800 mb-3">
                    {solution.title}
                  </h3>
                  <p className="text-slate-600 leading-relaxed">
                    {solution.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="bg-white rounded-xl p-8 shadow-lg border border-slate-100 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold text-slate-800 mb-4">Why Choose Our Custom Software Solutions?</h3>
            <div className="grid md:grid-cols-3 gap-6 text-left">
              <div>
                <h4 className="font-semibold text-slate-800 mb-2">Local Expertise</h4>
                <p className="text-slate-600">Built with deep understanding of Somali business practices and regulatory requirements.</p>
              </div>
              <div>
                <h4 className="font-semibold text-slate-800 mb-2">Scalable Architecture</h4>
                <p className="text-slate-600">Designed to grow with your business, from small operations to large enterprises.</p>
              </div>
              <div>
                <h4 className="font-semibold text-slate-800 mb-2">Ongoing Support</h4>
                <p className="text-slate-600">Comprehensive training, maintenance, and technical support for all our software solutions.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}