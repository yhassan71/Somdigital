export default function GISShowcaseSection() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* GIS Content */}
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-slate-800">
              Geographic Information System (GIS) - How It Works
            </h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              Our GIS solutions integrate spatial data with advanced analytics to provide powerful insights for decision-making. 
              From mapping and spatial analysis to location-based services, we transform geographic data into actionable intelligence.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-brand-blue rounded-full mt-2"></div>
                <div>
                  <h4 className="font-semibold text-slate-800">Data Collection & Integration</h4>
                  <p className="text-slate-600">Gathering spatial data from satellites, surveys, and GPS devices</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-brand-blue rounded-full mt-2"></div>
                <div>
                  <h4 className="font-semibold text-slate-800">Spatial Analysis</h4>
                  <p className="text-slate-600">Processing geographic data to identify patterns and relationships</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-brand-blue rounded-full mt-2"></div>
                <div>
                  <h4 className="font-semibold text-slate-800">Visualization & Mapping</h4>
                  <p className="text-slate-600">Creating interactive maps and visual representations of spatial data</p>
                </div>
              </div>
            </div>
          </div>

          {/* GIS Image */}
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
              alt="Geographic Information System workflow showing data collection, analysis, and mapping processes"
              className="w-full h-96 object-cover rounded-xl shadow-lg"
            />
            
            {/* Overlay with GIS workflow steps */}
            <div className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur-sm rounded-lg p-4">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="w-8 h-8 bg-brand-blue rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-white text-sm font-bold">1</span>
                  </div>
                  <p className="text-xs font-medium text-slate-800">Collect Data</p>
                </div>
                <div>
                  <div className="w-8 h-8 bg-brand-blue rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-white text-sm font-bold">2</span>
                  </div>
                  <p className="text-xs font-medium text-slate-800">Analyze</p>
                </div>
                <div>
                  <div className="w-8 h-8 bg-brand-blue rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-white text-sm font-bold">3</span>
                  </div>
                  <p className="text-xs font-medium text-slate-800">Visualize</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}