import { useState, useEffect } from "react";
import { Cpu, Menu, X, ChevronDown } from "lucide-react";
import { useLocation } from "wouter";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("home");
  const [aboutDropdownOpen, setAboutDropdownOpen] = useState(false);
  const [location, navigate] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll("section[id]");
      let current = "";
      
      sections.forEach((section) => {
        const sectionTop = section.getBoundingClientRect().top;
        if (sectionTop <= 100) {
          current = section.getAttribute("id") || "";
        }
      });

      setActiveSection(current);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    // If we're not on the home page, navigate to home first
    if (location !== "/") {
      navigate("/");
      // Wait for navigation to complete, then scroll
      setTimeout(() => {
        const element = document.getElementById(sectionId);
        if (element) {
          const headerOffset = 80;
          const elementPosition = element.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

          window.scrollTo({
            top: offsetPosition,
            behavior: "smooth",
          });
        }
      }, 100);
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        const headerOffset = 80;
        const elementPosition = element.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
          top: offsetPosition,
          behavior: "smooth",
        });
      }
    }
    setIsMenuOpen(false);
    setAboutDropdownOpen(false);
  };

  const navItems = [
    { id: "home", label: "Home" },
    { id: "services", label: "Services" },
    { id: "software-solutions", label: "Software Solutions" },
    { id: "portfolio", label: "Portfolio" },
    { id: "contact", label: "Contact" },
  ];

  const aboutItems = [
    { id: "about", label: "About Us", type: "section" },
    { id: "team", label: "Our Team", type: "page" },
  ];

  return (
    <nav className="bg-white shadow-lg fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Cpu className="h-8 w-8 text-brand-blue mr-3" />
              <span className="text-2xl font-bold text-slate-800">
                SOM<span className="text-brand-blue">Digital</span>
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`px-3 py-2 text-sm font-medium transition-colors duration-200 ${
                    activeSection === item.id
                      ? "text-slate-800 border-b-2 border-brand-blue"
                      : "text-slate-600 hover:text-brand-blue"
                  }`}
                >
                  {item.label}
                </button>
              ))}
              
              {/* About Us Dropdown */}
              <div className="relative">
                <button
                  onMouseEnter={() => setAboutDropdownOpen(true)}
                  onMouseLeave={() => setAboutDropdownOpen(false)}
                  className={`px-3 py-2 text-sm font-medium transition-colors duration-200 flex items-center ${
                    activeSection === "about" || location === "/team"
                      ? "text-slate-800 border-b-2 border-brand-blue"
                      : "text-slate-600 hover:text-brand-blue"
                  }`}
                >
                  About Us
                  <ChevronDown className="ml-1 h-4 w-4" />
                </button>
                
                {aboutDropdownOpen && (
                  <div 
                    className="absolute top-full left-0 mt-1 w-48 bg-white rounded-md shadow-lg z-50"
                    onMouseEnter={() => setAboutDropdownOpen(true)}
                    onMouseLeave={() => setAboutDropdownOpen(false)}
                  >
                    <div className="py-1">
                      {aboutItems.map((item) => (
                        <button
                          key={item.id}
                          onClick={() => {
                            if (item.type === "page") {
                              navigate(`/${item.id}`);
                            } else {
                              scrollToSection(item.id);
                            }
                            setAboutDropdownOpen(false);
                          }}
                          className="block w-full text-left px-4 py-2 text-sm text-slate-600 hover:bg-gray-100 hover:text-brand-blue"
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-slate-600 hover:text-brand-blue focus:outline-none focus:text-brand-blue"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white shadow-lg">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="text-slate-600 hover:text-brand-blue block px-3 py-2 text-base font-medium w-full text-left"
                >
                  {item.label}
                </button>
              ))}
              
              {/* Mobile About Us Section */}
              <div className="border-t border-gray-200 pt-2">
                <div className="px-3 py-2 text-sm font-semibold text-slate-800">About Us</div>
                {aboutItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      if (item.type === "page") {
                        navigate(`/${item.id}`);
                      } else {
                        scrollToSection(item.id);
                      }
                      setIsMenuOpen(false);
                    }}
                    className="text-slate-600 hover:text-brand-blue block px-6 py-2 text-base font-medium w-full text-left"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
