import { CheckCircle } from "lucide-react";
import somaliaMapImage from "@assets/mappa_-_somalia2_1753807711746.jpg";

export default function AboutUsSection() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content Side */}
          <div className="space-y-8">
            <div>
              <h2 className="text-4xl font-bold text-slate-800 mb-6">Who We Are</h2>
              <p className="text-lg text-slate-600 leading-relaxed mb-6">
                Based in Mogadishu, Somalia, we are a leading technology company providing comprehensive IT solutions including software development, system integration, digital transformation, GIS mapping, GPS solutions, and enterprise technology services. Our mission is to empower businesses and organizations with cutting-edge technology solutions.
              </p>
              <p className="text-lg text-slate-600 leading-relaxed">
                With deep expertise across multiple technology domains and digital innovation, we serve clients across Somalia and the Horn of Africa, delivering scalable solutions that drive growth and operational excellence.
              </p>
            </div>

            {/* Key Points */}
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-6 h-6 text-brand-blue mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-slate-800">High Skills in Information Technology Services</h4>
                  <p className="text-slate-600">Expert team with advanced IT capabilities in software development, system integration, and digital transformation</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-6 h-6 text-brand-blue mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-slate-800">Local Expertise, Global Standards</h4>
                  <p className="text-slate-600">Deep understanding of Somalia's unique challenges with international best practices.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-6 h-6 text-brand-blue mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-slate-800">Comprehensive Technology Solutions</h4>
                  <p className="text-slate-600">Full-service IT capabilities from enterprise software to GIS mapping and digital infrastructure solutions.</p>
                </div>
              </div>
            </div>

            {/* CTA Button */}
            <div className="pt-4">
              <button 
                onClick={() => {
                  const element = document.getElementById("contact");
                  if (element) {
                    const headerOffset = 80;
                    const elementPosition = element.getBoundingClientRect().top;
                    const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                    window.scrollTo({ top: offsetPosition, behavior: "smooth" });
                  }
                }}
                className="bg-brand-blue hover:bg-blue-800 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-200"
              >
                Get Started Today
              </button>
            </div>
          </div>

          {/* Somalia Map Side */}
          <div className="relative">
            <img 
              src={somaliaMapImage} 
              alt="Somalia States and Regions Map showing Somaliland, Puntland, Galmudug, Hirshabelle, South West, Jubaland and major cities"
              className="rounded-xl shadow-lg w-full h-auto object-cover"
            />
            
            {/* Overlay with company info */}
            <div className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur-sm rounded-lg p-4">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-brand-blue rounded-full flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                  </svg>
                </div>
                <div>
                  <h4 className="font-semibold text-slate-800">Nationwide Coverage</h4>
                  <p className="text-sm text-slate-600">Serving all regions of Somalia with GIS expertise</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}