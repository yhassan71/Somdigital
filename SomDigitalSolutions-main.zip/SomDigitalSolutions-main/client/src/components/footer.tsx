import { Cpu } from "lucide-react";
import { FaFacebook, FaTwitter, FaLinkedin, FaInstagram } from "react-icons/fa";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  const serviceLinks = [
    "GIS Mapping",
    "GPS Solutions", 
    "Software Development",
    "Digital Addressing",
    "Data Collection",
  ];

  const companyLinks = [
    { label: "About Us", sectionId: "about" },
    { label: "Portfolio", sectionId: "portfolio" },
    { label: "Contact", sectionId: "contact" },
    { label: "Careers", sectionId: "#" },
    { label: "Privacy Policy", sectionId: "#" },
  ];

  return (
    <footer className="bg-slate-800 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div className="space-y-6">
            <div className="flex items-center">
              <Cpu className="h-8 w-8 text-brand-blue mr-3" />
              <span className="text-2xl font-bold">
                SOM<span className="text-brand-blue">Digital</span>
              </span>
            </div>
            <p className="text-slate-300 leading-relaxed">
              Leading technology solutions provider in Somalia, specializing in GIS mapping, GPS solutions, and digital transformation services.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-400 hover:text-brand-blue transition-colors duration-200">
                <FaFacebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-brand-blue transition-colors duration-200">
                <FaTwitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-brand-blue transition-colors duration-200">
                <FaLinkedin className="w-5 h-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-brand-blue transition-colors duration-200">
                <FaInstagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Services</h4>
            <ul className="space-y-3">
              {serviceLinks.map((service, index) => (
                <li key={index}>
                  <button 
                    onClick={() => scrollToSection("services")}
                    className="text-slate-300 hover:text-brand-blue transition-colors duration-200 text-left"
                  >
                    {service}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Company</h4>
            <ul className="space-y-3">
              {companyLinks.map((link, index) => (
                <li key={index}>
                  <button 
                    onClick={() => link.sectionId !== "#" && scrollToSection(link.sectionId)}
                    className="text-slate-300 hover:text-brand-blue transition-colors duration-200 text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Contact Info</h4>
            <div className="space-y-4 text-slate-300">
              <div className="flex items-start space-x-3">
                <span className="text-brand-blue mt-1">📍</span>
                <span>Mogadishu, Somalia</span>
              </div>
              <div className="flex items-start space-x-3">
                <span className="text-brand-blue mt-1">📞</span>
                <span>+252 611135696</span>
              </div>
              <div className="flex items-start space-x-3">
                <span className="text-brand-blue mt-1">✉</span>
                <span>info@somdigitalsolutions.so</span>
              </div>
              <div className="flex items-start space-x-3">
                <span className="text-brand-blue mt-1">🕐</span>
                <span>8:00 AM – 4:45 PM</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-slate-400 text-center md:text-left">
              © 2024 SOM Digital Solutions. All rights reserved.
            </p>
            <p className="text-slate-400 text-center md:text-right">
              Powered by modern web technologies
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
