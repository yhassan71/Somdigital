import { ExternalLink } from "lucide-react";

export default function CTASection() {
  return (
    <section className="py-12 bg-slate-100">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl p-8 text-center shadow-lg border border-gray-200">
          <h2 className="text-2xl md:text-3xl font-bold text-slate-800 mb-4">
            Explore Our Partner Platform
          </h2>
          <p className="text-slate-600 mb-6 max-w-2xl mx-auto">
            Discover comprehensive urban compliance and standards management solutions 
            designed specifically for Somalia's development needs.
          </p>
          <a
            href="https://app.ucssom.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center bg-brand-blue hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors duration-200 shadow-lg"
          >
            <span>Visit Urban Compliance Standards Somalia</span>
            <ExternalLink className="ml-2 h-4 w-4" />
          </a>
        </div>
      </div>
    </section>
  );
}