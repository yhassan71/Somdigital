export default function PortfolioSection() {
  const projects = [
    {
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      title: "E-Commerce Platform",
      category: "Web Development",
      alt: "Modern responsive e-commerce website development"
    },
    {
      image: "https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      title: "Enterprise Management System",
      category: "Software Development",
      alt: "Custom enterprise software development and management system"
    },
    {
      image: "https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      title: "Social Media Campaign",
      category: "Digital Marketing",
      alt: "Digital marketing strategy and social media campaign management"
    },
    {
      image: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      title: "Corporate Website",
      category: "Website Development",
      alt: "Professional corporate website development and design"
    },
    {
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250",
      title: "GPS Tracking Solutions",
      category: "GIS Solutions",
      alt: "Location-based services and GPS tracking technology"
    },
    {
      image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=250",
      title: "Mobile App Development",
      category: "Software Development",
      alt: "Custom mobile application development and deployment"
    },
  ];

  return (
    <section id="portfolio" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-800 mb-4">Our Work Showcase</h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="bg-slate-50 rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
              <img 
                src={project.image} 
                alt={project.alt} 
                className="w-full h-48 object-cover" 
              />
              <div className="p-6">
                <h4 className="text-xl font-bold text-slate-800 mb-2">
                  <a href="#" className="hover:text-brand-blue transition-colors duration-200">
                    {project.title}
                  </a>
                </h4>
                <p className="text-slate-600">- {project.category}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
