export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div>
              <h2 className="text-4xl font-bold text-slate-800 mb-6">About SOM Digital Solutions</h2>
              <div className="space-y-6 text-lg text-slate-600 leading-relaxed">
                <p>
                  Based in Mogadishu, Somalia, SOM Digital Solutions is a leading technology company specializing in comprehensive digital transformation services. Our mission is to map and digitize Somalia through cutting-edge technology solutions.
                </p>
                <p>
                  <strong className="text-slate-800">Our Vision:</strong> Turn dreams into reality through cutting-edge technology and innovative solutions that drive growth and efficiency for businesses across Somalia.
                </p>
                <p>
                  <strong className="text-slate-800">Our Goals:</strong> Deliver high-quality software solutions while building trusted partnerships with our clients. We focus on providing reliable, scalable, and user-friendly systems that address complex business challenges.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="text-center p-6 bg-white rounded-xl shadow-lg">
                <div className="text-3xl font-bold text-brand-blue mb-2">15+</div>
                <div className="text-slate-600">Projects Completed</div>
              </div>
              <div className="text-center p-6 bg-white rounded-xl shadow-lg">
                <div className="text-3xl font-bold text-brand-blue mb-2">50+</div>
                <div className="text-slate-600">Happy Clients</div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <img 
              src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Professional team working on technology solutions" 
              className="rounded-xl shadow-lg w-full h-auto" 
            />
            
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <h3 className="text-2xl font-bold text-slate-800 mb-4">Our Leadership</h3>
              <p className="text-slate-600 leading-relaxed">
                Led by experienced professionals in the technology sector, our team combines deep technical expertise with comprehensive understanding of the Somali market needs and challenges.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
