import { useEffect, useRef } from 'react';

export default function InteractiveGISSection() {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const replayBtnRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const loadMapLibre = async () => {
      if (typeof window === 'undefined') return;

      // Load MapLibre CSS
      if (!document.querySelector('link[href*="maplibre-gl.css"]')) {
        const link = document.createElement('link');
        link.href = 'https://unpkg.com/maplibre-gl@2.4.0/dist/maplibre-gl.css';
        link.rel = 'stylesheet';
        document.head.appendChild(link);
      }

      // Load MapLibre JS
      if (!(window as any).maplibregl) {
        const script = document.createElement('script');
        script.src = 'https://unpkg.com/maplibre-gl@2.4.0/dist/maplibre-gl.js';
        script.onload = () => initializeMap();
        document.head.appendChild(script);
      } else {
        initializeMap();
      }
    };

    const initializeMap = () => {
      if (!mapRef.current || mapInstanceRef.current) return;

      const maplibregl = (window as any).maplibregl;

      const map = new maplibregl.Map({
        container: mapRef.current,
        style: 'https://api.maptiler.com/maps/streets/style.json?key=VtW71S8dEg0ogC8gqqe5',
        center: [45, 5],
        zoom: 1.5,
        pitch: 0,
        bearing: 0
      });

      mapInstanceRef.current = map;

      map.addControl(new maplibregl.NavigationControl());

      // Steps: camera position + overlay text
      const steps = [
        { center: [45, 5], zoom: 1.5, pitch: 0, bearing: 0, duration: 3000, text: "Exploring the World" },
        { center: [46.1996, 6.0], zoom: 5, pitch: 20, bearing: 0, duration: 3000, text: "Flying into Somalia" },
        { center: [45.3182, 2.0469], zoom: 10, pitch: 40, bearing: 20, duration: 3000, text: "Welcome to Mogadishu" },
        { center: [45.3282, 2.0469], zoom: 16, pitch: 60, bearing: -20, duration: 4000, text: "Street View – Mogadishu" }
      ];

      const playTour = () => {
        if (replayBtnRef.current) {
          replayBtnRef.current.style.display = 'none'; // hide replay while playing
        }
        if (overlayRef.current) {
          overlayRef.current.style.opacity = '1';
        }

        let i = 0;
        const fly = () => {
          if (i < steps.length) {
            if (overlayRef.current) {
              overlayRef.current.innerText = steps[i].text;
            }
            map.flyTo({
              center: steps[i].center,
              zoom: steps[i].zoom,
              pitch: steps[i].pitch,
              bearing: steps[i].bearing,
              duration: steps[i].duration,
              essential: true
            });
            setTimeout(() => { 
              i++; 
              fly(); 
              if (i === steps.length) {
                // Fade out overlay and show replay after tour ends
                setTimeout(() => { 
                  if (overlayRef.current) overlayRef.current.style.opacity = '0';
                  if (replayBtnRef.current) replayBtnRef.current.style.display = 'block';
                }, 2000);
              }
            }, steps[i].duration);
          }
        };
        fly();
      };

      map.on('load', () => {
        // Add 3D buildings
        try {
          map.addLayer({
            'id': '3d-buildings',
            'source': 'openmaptiles',
            'source-layer': 'building',
            'type': 'fill-extrusion',
            'minzoom': 15,
            'paint': {
              'fill-extrusion-color': '#aaa',
              'fill-extrusion-height': ['get', 'height'],
              'fill-extrusion-base': ['get', 'min_height'],
              'fill-extrusion-opacity': 0.6
            }
          });
        } catch (e) {
          console.log('3D buildings layer not available with this style');
        }

        playTour();
      });

      // Store playTour function for replay button
      (map as any).playTour = playTour;
    };

    loadMapLibre();

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  const handleReplay = () => {
    if (mapInstanceRef.current && (mapInstanceRef.current as any).playTour) {
      if (overlayRef.current) {
        overlayRef.current.style.opacity = '1';
      }
      (mapInstanceRef.current as any).playTour();
    }
  };

  return (
    <section className="py-20 bg-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-slate-800 mb-4">
            Interactive GIS Mapping Experience
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Experience our GIS animation from global view to street-level detail in Mogadishu. 
            Watch the smooth zoom and 3D building visualization.
          </p>
        </div>

        <div className="relative bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="relative h-96 md:h-[500px]">
            {/* Overlay Text */}
            <div 
              ref={overlayRef}
              className="absolute top-20 left-1/2 transform -translate-x-1/2 z-50 text-white text-2xl md:text-3xl font-bold text-center transition-opacity duration-1000 bg-black/60 backdrop-blur-sm rounded-lg px-6 py-3"
              style={{ textShadow: '0 0 15px rgba(0,0,0,0.9)' }}
            >
              Exploring the World
            </div>

            {/* Replay Button */}
            <button
              ref={replayBtnRef}
              onClick={handleReplay}
              className="absolute top-4 left-4 z-40 bg-black/70 hover:bg-black/90 text-white px-4 py-2 rounded-lg font-medium transition-colors duration-200"
              style={{ display: 'none' }}
            >
              Replay Tour
            </button>

            {/* Map Container */}
            <div ref={mapRef} className="w-full h-full" />
          </div>
          

        </div>

        <div className="text-center mt-8">
          <p className="text-slate-600 max-w-2xl mx-auto">
            This animation demonstrates our GIS capabilities with smooth camera movements, 
            3D visualization, and precise geographic positioning from continental to street-level detail.
          </p>
        </div>
      </div>
    </section>
  );
}