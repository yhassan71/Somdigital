# SOM Digital Solutions - Company Website

## Overview

This is a modern full-stack web application for SOM Digital Solutions, a technology company based in Mogadishu, Somalia. The application serves as a corporate website showcasing the company's GIS mapping, GPS solutions, and digital transformation services. It features a clean, professional design with a contact form system for lead generation.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Radix UI primitives with shadcn/ui component system
- **Styling**: Tailwind CSS with custom design tokens and CSS variables
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API endpoints for contact form submissions
- **Development**: Hot module replacement and error overlay for development experience

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM (Active)
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Storage Implementation**: DatabaseStorage class using Drizzle ORM for production data persistence

## Key Components

### Frontend Components
- **Navigation**: Responsive navigation with smooth scrolling to sections
- **Hero Section**: Company introduction with call-to-action buttons
- **Services Section**: Grid layout showcasing six main service offerings
- **Portfolio Section**: Project showcase with image galleries
- **About Section**: Company information with statistics and leadership details
- **Contact Section**: Interactive contact form with validation
- **Footer**: Company information, service links, and social media

### Backend Components
- **Express Server**: Main application server with middleware setup
- **Contact API**: Endpoints for creating and retrieving contact submissions
- **Storage Layer**: Abstracted storage interface with memory and database implementations
- **Error Handling**: Centralized error handling with proper HTTP status codes

### Shared Components
- **Schema Definitions**: Zod schemas for data validation across client and server
- **Type Safety**: Shared TypeScript types generated from Drizzle schemas

## Data Flow

1. **Client Interaction**: User fills out contact form on the website
2. **Form Validation**: Client-side validation using React Hook Form and Zod schemas
3. **API Request**: Form data sent to `/api/contact` endpoint via TanStack Query mutation
4. **Server Processing**: Express server validates data and stores contact submission
5. **Database Storage**: Contact submission saved to PostgreSQL via Drizzle ORM
6. **Response Handling**: Client receives success/error feedback via toast notifications
7. **State Updates**: TanStack Query invalidates and refetches relevant data

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-orm**: Type-safe database ORM with PostgreSQL support
- **@tanstack/react-query**: Server state management and caching
- **@hookform/resolvers**: Form validation resolver for Zod integration

### UI Dependencies
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Modern icon library
- **react-icons**: Additional social media icons

### Development Dependencies
- **vite**: Fast build tool with HMR support
- **tsx**: TypeScript execution for Node.js
- **esbuild**: Fast JavaScript bundler for production builds

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite builds React application to `dist/public`
2. **Backend Build**: esbuild bundles server code to `dist/index.js`
3. **Static Assets**: Client assets served from Express in production

### Environment Configuration
- **Development**: Uses in-memory storage, Vite dev server, and HMR
- **Production**: Connects to PostgreSQL database, serves static files from Express
- **Database**: Requires `DATABASE_URL` environment variable for PostgreSQL connection

### Hosting Requirements
- Node.js runtime environment
- PostgreSQL database (Neon Database recommended)
- Static file serving capability
- Environment variable support for database configuration

The application is designed to be deployed on platforms like Railway, Vercel, or similar Node.js hosting services with PostgreSQL database support.